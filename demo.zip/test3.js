
define("b",function(require,exports){
	var d = require("d");
	exports.x  = function(){
		return "bx";
	}
});